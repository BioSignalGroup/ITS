name: Control Box Front Panel

size: 378x80

type : doublesided

silk screen : NO!

solder mask : yes (top, bottom)

surface : galvanic Au (gold) (18um)

material : FR4

thickness : 1.55mm
