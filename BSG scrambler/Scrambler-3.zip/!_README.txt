name: Scrambler-3

size: 160x233

type : doublesided

silk screen : Top

solder mask : yes (top, bottom)

surface : galvanic Au (gold) (18um)

material : FR4

thickness : 1.55mm (0.063")

*.TOP  -  Top etch
*.BOT  -  Bottom etch
*.SMT  -  Solder Mask Top
*.SMB  -  Solder Mask Bottom
*.AST  -  Legend (assembly) Top
*.DRD  -  Drill Gerber


